<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
	<style type="text/css">
		.table1 {
    font-family: serif;
    color: #444;
    border-collapse: collapse;
    width: 95%;
    border: 1px solid #f2f5f7;
	}

	.table1 tr th{
	    background: #35A9DB;
	    color: #fff;
	    font-weight: normal;
	}

	.table1, th, td {
	    padding: 10px 30px;
	    text-align: center;
	}

	.table1 tr:hover {
	    background-color: #f5f5f5;
	}

	.table1 tr:nth-child(even) {
	    background-color: #f2f2f2;
	}
	</style>

</head>
<body>
	<center><h1>Daftar Mahasiswa</h1></center>
	<center>
		<a href="<?php echo base_url() ?>index.php/mahasiswa/tambah/" class="btn btn-md btn-success">Tambah Data Mahasiswa</a>
	<table class="table1" style="margin:20px auto;" border="1">
		<tr>
			<th>No</th>
			<th>Nim</th>
			<th>Nama Mahasiswa</th>
			<th>Jenis Kelamin</th>
			<th>Alamat</th>
			<th>Action</th>
		</tr>
		<?php 
		$no = 1;
		foreach($mahasiswa as $u){ 
		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $u->nim ?></td>
			<td><?php echo $u->nama_mhs ?></td>
			<td><?php echo $u->jns_klm ?></td>
			<td><?php echo $u->Alamat ?></td>
			<td>
				<a href="<?php echo base_url()?>index.php/mahasiswa/edit/<?php echo $u->no ?>" class="btn btn-sm btn-success">Edit</a>
                <a href="<?php echo base_url()?>index.php/mahasiswa/hapus/<?php echo $u->no ?>" class="btn btn-sm btn-danger">Hapus</a><!-- link ini tertuju pada controller pegawai !-->
			      
			</td>
		</tr>
		<?php } ?>
	</table>
</body>
</html>