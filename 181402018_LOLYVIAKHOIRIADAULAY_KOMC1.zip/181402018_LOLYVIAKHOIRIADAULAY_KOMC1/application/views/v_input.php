<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
	<style type="text/css">
		.table1 {
    font-family: sans-serif;
    color: #444;
    width: 40%;
    border: 0px solid #FFFAF0;
    padding: 10px;
	}

	</style>
</head>
<body style="background-color: #FFE4C4; font-family: serif; ">
	
		<b>
		<center>
		<a href="<?php echo base_url() ?>index.php/mahasiswa/tampil/" class="btn btn-md btn-success">Tampilkan Data</a>
		<h1></h1>
		<h3>Tambah data baru</h3>
	<form action="<?php echo base_url(). 'index.php/mahasiswa/tambah_aksi'; ?>" method="post"><!--berfungsi untuk mengambil data melalui controller!-->
		<table class="table1" style="margin:20px auto; font-family: serif; ">
			<table border="3">
			<tr>
				<td>Nim</td>
				<td><input type="text" name="nim"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama_mhs"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td><input type="text" name="jns_klm"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="Alamat"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-md btn-success" value="Tambah"></td>
			</tr>
		</table>
		</table>
	</form>	
</center>
</body>
</html>