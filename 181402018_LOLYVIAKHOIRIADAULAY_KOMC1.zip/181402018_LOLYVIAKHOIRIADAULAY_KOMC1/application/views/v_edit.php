<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
	<style type="text/css">
		.table1 {
    font-family: sans-serif;
    color: #444;
    width: 40%;
    border: 0px solid #FFFAF0;
    padding: 10px;
	}
</style>
</head>
<body style="background-color: #D2B48C ; font-family: serif; ">
	<center>
		<h3>Edit Data</h3>
	<?php foreach($mahasiswa as $u){ ?>
	<form action="<?php echo base_url(). 'index.php/mahasiswa/update'; ?>" method="post">
		<table class="table1" style="margin:20px auto; font-family: serif; ">
			<table border="3">
			<tr>
				<td>Nim</td>
				<td><input type="text" name="nim" value="<?php echo $u->nim ?>"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td>
					<input type="hidden" name="nama" value="<?php echo $u->nama_mhs ?>">
					<input type="text" name="nama_mhs" value="<?php echo $u->nama_mhs ?>">
				</td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td><input type="text" name="jns_klm" value="<?php echo $u->jns_klm ?>"></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type="text" name="alamat" value="<?php echo $u->Alamat ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-md btn-success" value="Simpan"></td>
			</tr>
		</table>
		</table>
	</form>	
	</center>
	<?php } ?>
</body>
</html>