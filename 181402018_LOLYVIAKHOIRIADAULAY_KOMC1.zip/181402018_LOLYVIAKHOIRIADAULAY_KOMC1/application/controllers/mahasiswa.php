<?php 
 
class Mahasiswa extends CI_Controller{
 
	function __construct(){
		parent::__construct();		
		$this->load->model('m_data');
                $this->load->helper('url');
	}
 
	function index(){
		$data['mahasiswa'] = $this->m_data->tampil_data()->result();
		$this->load->view('v_input',$data);
	}
	function tampil(){
		$data['mahasiswa'] = $this->m_data->tampil_data()->result();
		$this->load->view('v_tampil',$data);
	}
	function tambah(){
		$this->load->view('v_input');//melalui controller ditampilkan view pada v_tampil
	}
	function tambah_aksi(){
	$nim = $this->input->post('nim');//menangkap inputan dari form dan menjadikannya ke array
	$nama_mhs = $this->input->post('nama_mhs');
	$jns_klm = $this->input->post('jns_klm');
	$Alamat = $this->input->post('Alamat');

	$data = array(
		'nim' => $nim,
		'nama_mhs' => $nama_mhs,
		'jns_klm' => $jns_klm,
		'Alamat' => $Alamat
	);
		$this->m_data->input_data($data,'mahasiswa');//menginput data ke database dengan model m_data
		redirect('mahasiswa/index');//kemudian mengalihkan ke input
	}
	function hapus($no){//menangkap variabel no yang dikirim melalui url dari link pada v_tampil
		$where = array('no' => $no);
		$this->m_data->hapus_data($where,'mahasiswa');//mengambil data yang di hapus ke database
		redirect('mahasiswa/tampil');
	}
	function edit($no){
		$where = array('no' => $no);
		$data['mahasiswa'] = $this->m_data->edit_data($where,'mahasiswa')->result();//menggenerate hasil query menjadi array
		$this->load->view('v_edit',$data);//mengambil view v_edit untuk menjadi tempat form yang diedit
	}
	function update(){
	$no = $this->input->post('no');//menjadikan no menjadi array
	$nim = $this->input->post('nim');
	$nama_mhs= $this->input->post('nama_mhs');
	$jns_klm = $this->input->post('jns_klm');
	$Alamat = $this->input->post('Alamat');

	$data = array(
		'nim' => $nim,
		'nama_mhs' => $nama_mhs,
		'jns_klm' => $jns_klm,
		'Alamat' => $Alamat
	);

	$where = array(
		'no' => $no
	);

	$this->m_data->update_data($where,$data,'mahasiswa');
	redirect('mahasiswa/tampil');
}
}